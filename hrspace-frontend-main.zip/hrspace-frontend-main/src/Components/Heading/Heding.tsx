import "./Heading.scss";

export function Heading() {
return(
    <section className="heading">
        <p className="heading__pass">Главная / Добавление заявки</p>
        <h1 className="heading__title">Добавление заявки</h1>
    </section>
)
}